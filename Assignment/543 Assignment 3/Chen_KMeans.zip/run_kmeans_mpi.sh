#!/bin/sh
mpirun -np 5 kmeans_mpi --cluster_num 3 --star_files ./stars-9.txt ./stars-15.txt ./stars-82.txt
