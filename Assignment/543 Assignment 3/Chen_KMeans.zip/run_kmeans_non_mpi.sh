#!/bin/sh
./kmeans_non_mpi 3 ./stars-9.txt ./stars-15.txt ./stars-82.txt
